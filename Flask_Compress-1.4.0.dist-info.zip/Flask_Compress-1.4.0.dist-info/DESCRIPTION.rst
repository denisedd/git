Full documentation can be found on the Flask-Compress "Home Page".


