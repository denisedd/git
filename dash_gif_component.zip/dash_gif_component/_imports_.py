from .GifPlayer import GifPlayer

__all__ = [
    "GifPlayer"
]